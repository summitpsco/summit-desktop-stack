-- items/calendar.lua
-- Date + time pill + Zen mode, fully driven by theme.lua
-- ONLY approved local overrides: calendar-specific text padding + time width

local theme  = require("theme")
local colors = theme.colors
local layout = theme.layout
local font   = theme.font

------------------------------------------------------------
-- APPROVED: local-only calendar padding + width
------------------------------------------------------------
local TEXT_PAD       = 8   -- replaces layout.text_pad
local CALENDAR_WIDTH = 49  -- replaces layout.calendar_width (Felix default)

------------------------------------------------------------
-- Helper: 12-hour time without leading zero (e.g. "5:03")
------------------------------------------------------------
local function formatted_time()
  local h24 = tonumber(os.date("%H"))
  local m   = os.date("%M")
  local h12 = h24 % 12
  if h12 == 0 then h12 = 12 end
  return string.format("%d:%s", h12, m)
end

------------------------------------------------------------
-- Spacer before the pill (uses theme layout gap)
------------------------------------------------------------
sbar.add("item", "calendar.left_padding", {
  position = "right",
  width    = layout.group_gap,
})

------------------------------------------------------------
-- Main calendar item (inner content only)
------------------------------------------------------------
local cal = sbar.add("item", "calendar", {
  position    = "right",
  update_freq = 30,

  -- Inner pill padding
  padding_left  = layout.pill_inner_pad_x,
  padding_right = layout.pill_inner_pad_x,

  -- Inner item: transparent, bracket provides pill look
  background = {
    color         = colors.transparent,
    border_color  = colors.transparent,
    border_width  = 0,
    corner_radius = layout.pill_radius,
  },

  icon = {
    -- Date text, e.g. "Thu. 01 Jan."
    font = {
      family = font.text.family,
      style  = font.style_map[font.weight_text],
      size   = font.sizes.sm,
    },
    color        = colors.text,
    padding_left = TEXT_PAD,
  },

  label = {
    -- Time text, e.g. "3:12"
    font = {
      family = font.numbers.family,
      style  = font.style_map[font.weight_numbers],
      size   = font.sizes.sm,
    },
    color         = colors.text,
    align         = "right",
    padding_right = TEXT_PAD,
    width         = CALENDAR_WIDTH,
  },
})

------------------------------------------------------------
-- Outer pill bracket (same geometry as battery pill)
------------------------------------------------------------
sbar.add("bracket", "calendar.bracket", { cal.name }, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
})

------------------------------------------------------------
-- Spacer after the pill (same group gap)
------------------------------------------------------------
sbar.add("item", "calendar.right_padding", {
  position = "right",
  width    = layout.group_gap,
})

------------------------------------------------------------
-- Date + time updates (12-hour format)
------------------------------------------------------------
cal:subscribe({ "forced", "routine", "system_woke" }, function()
  local date_str = os.date("%a. %d %b.")  -- e.g. "Thu. 01 Jan."
  local time_str = formatted_time()       -- e.g. "3:12"
  cal:set({
    icon  = { string = date_str },
    label = { string = time_str },
  })
end)

------------------------------------------------------------
-- Zen mode: only show battery + calendar
------------------------------------------------------------
local zen_mode = false

local function zen_on()
  sbar.exec(string.format([[
sketchybar --set '/.*/' drawing=off \
           --set %s drawing=on \
           --set '/widgets\.battery$/' drawing=on
]], cal.name))

  zen_mode = true
end

local function zen_off()
  -- Full bar reset (your existing behaviour)
  sbar.exec("sketchybar --reload")
  zen_mode = false
end

-- Click toggles Zen mode ONLY (no open Calendar.app)
cal:subscribe("mouse.clicked", function()
  if zen_mode then
    zen_off()
  else
    zen_on()
  end
end)