-- items/spaces.lua
-- AeroSpace workspaces pill (accordion) at position "q"
-- Goal: match right-side pill sizing via theme.lua

local theme     = require("theme")
local colors    = theme.colors
local layout    = theme.layout
local font      = theme.font

local app_icons = require("helpers.app_icons")

------------------------------------------------------------
-- Workspaces
------------------------------------------------------------
local workspace_ids = { 1, 2, 3, 4, 5, 6 }
local spaces      = {}
local space_names = {}

------------------------------------------------------------
-- Accordion tuning (LOCAL)
-- (These are the only ones that stay local)
------------------------------------------------------------
local FIRST_SPACE_PADDING_LEFT = 0
local OVERLAP_PADDING_LEFT     = -3
local SPACE_PADDING_RIGHT      = 2

-- Notch gap spacer
local NOTCH_GAP_WIDTH          = 18

------------------------------------------------------------
-- IMPORTANT: derive “pill feel” from theme.lua
------------------------------------------------------------
local NUMBER_PAD_LEFT  = layout.pill_inner_pad_x
local NUMBER_PAD_RIGHT = layout.pill_inner_pad_x
local APPS_PAD_RIGHT   = layout.pill_inner_pad_x

------------------------------------------------------------
-- Helpers
------------------------------------------------------------
local function get_focused_workspace(cb)
  sbar.exec("aerospace list-workspaces --focused", function(out)
    out = (out or ""):gsub("[\r\n]", " ")
    local id = tonumber(out:match("(%d+)")) or 1
    cb(id)
  end)
end

local function update_space_highlights(focused_ws)
  focused_ws = tonumber(focused_ws) or 1
  for _, id in ipairs(workspace_ids) do
    local active = (id == focused_ws)
    spaces[id]:set({
      icon  = { highlight = active },
      label = { highlight = active },
    })
  end
end

local ICON_SPACER = ""

local function update_icons_for_workspace(id)
  sbar.exec(
    "aerospace list-windows --workspace " .. id .. " --format '%{app-name}%{newline}'",
    function(output)
      local icons_line = ""
      for line in string.gmatch(output or "", "[^\r\n]+") do
        if line ~= "" then
          local icon = app_icons[line] or app_icons["Default"]
          if icons_line == "" then
            icons_line = icon
          else
            icons_line = icons_line .. ICON_SPACER .. icon
          end
        end
      end
      spaces[id]:set({ label = icons_line })
    end
  )
end

local function update_all_icons()
  for _, id in ipairs(workspace_ids) do
    update_icons_for_workspace(id)
  end
end

local function refresh_all()
  get_focused_workspace(function(focused)
    update_space_highlights(focused)
    update_all_icons()
  end)
end

------------------------------------------------------------
-- Create workspace pills
-- (Create 6→1 so left-side pills stack on top of right-side pills)
-- Visual order forced via `order` in position "q"
------------------------------------------------------------
for index = #workspace_ids, 1, -1 do
  local id = workspace_ids[index]
  local name = "space." .. id

  local true_index = id
  local inner_color = (true_index % 2 == 1) and colors.pill_bg_alt or colors.pill_bg_main
  local padding_left = (true_index == 1) and FIRST_SPACE_PADDING_LEFT or OVERLAP_PADDING_LEFT

  local space = sbar.add("item", name, {
    position = "q",

    icon = {
      font = {
        family = font.numbers.family,
        style  = font.style_map[font.weight_numbers],
        size   = font.sizes.md,
      },
      string          = id,
      padding_left    = NUMBER_PAD_LEFT,
      padding_right   = NUMBER_PAD_RIGHT,
      color           = colors.text_muted,
      highlight_color = colors.accent,
    },

    label = {
      padding_right   = APPS_PAD_RIGHT,
      color           = colors.text_muted,
      highlight_color = colors.accent,
      font            = "sketchybar-app-font:Regular:16.0",
      y_offset        = -1,
    },

    padding_left  = padding_left,
    padding_right = SPACE_PADDING_RIGHT,

    background = {
      color         = inner_color,
      border_width  = layout.pill_border_width,
      border_color  = colors.pill_border,
      height        = layout.pill_height,
      corner_radius = layout.pill_radius,
    },
  })

  spaces[id] = space
  table.insert(space_names, name)

  space:subscribe("mouse.clicked", function(env)
    if env.BUTTON == "right" then
      sbar.exec("aerospace move-node-to-workspace " .. id)
    else
      sbar.exec("aerospace workspace " .. id)
    end
  end)
end

-- NOTCH GAP SPACER (EXTERNAL DISPLAYS ONLY)
-- IMPORTANT: drawing=true so it actually reserves width.
-- Set DISPLAY_IDS to your external display numbers from `sketchybar --query displays`
local DISPLAY_IDS = { 1, 3 }  -- <-- change these to your EXTERNAL displays

for _, d in ipairs(DISPLAY_IDS) do
  sbar.add("item", "spaces.notch_gap." .. d, {
    position = "q",
    display  = d,
    width    = NOTCH_GAP_WIDTH,
    drawing  = true,

    icon = { drawing = false },
    label = { drawing = false },
    background = { drawing = false },
  })
end

------------------------------------------------------------
-- Wrapper behind all mini-pills
-- Make this EXACTLY the same pill height/radius as the right-side pills
------------------------------------------------------------
sbar.add("bracket", "spaces.group", space_names, {
  background = {
    color         = colors.pill_bg_main,
    border_width  = 0,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
})

------------------------------------------------------------
-- Observer
------------------------------------------------------------
local obs = sbar.add("item", "spaces.observer", {
  drawing     = false,
  updates     = true,
  update_freq = 3,
})

obs:subscribe("aerospace_workspace_change", function()
  refresh_all()
end)

obs:subscribe({ "forced", "routine", "system_woke" }, function()
  refresh_all()
end)

refresh_all()