-- items/media.lua
-- Spotify mini controls (prev / play-pause / next + 15-char track)
-- No popup. Styling ONLY from theme.lua. Position stays "e".

local theme = require("theme")
local icons = require("icons")

local colors = theme.colors
local layout = theme.layout
local font   = theme.font

--------------------------------------------------
-- Helpers (no fallbacks)
--------------------------------------------------

local function font_text(size_key)
  return {
    family = font.text.family,
    style  = font.style_map[font.weight_text],
    size   = font.sizes[size_key],
  }
end

local function font_icon(size_key)
  return {
    family = font.icon.family,
    style  = font.style_map[font.weight_icons],
    size   = font.sizes[size_key],
  }
end

local function cut15(s)
  if not s or s == "" then return "" end
  if #s <= 15 then return s end
  return string.sub(s, 1, 15)
end

--------------------------------------------------
-- SF Symbols glyphs
--------------------------------------------------
local GLYPH_PREV  = "􀊎"
local GLYPH_NEXT  = "􀊐"
local GLYPH_PLAY  = "􀊄"
local GLYPH_PAUSE = "􀊆"

--------------------------------------------------
-- Items (content only; bracket draws pill)
--------------------------------------------------

local spotify_prev = sbar.add("item", "spotify.prev", {
  position = "e",
  padding_left  = 0,
  padding_right = 0,
  background = { drawing = false },

  icon = {
    string = GLYPH_PREV,
    font   = font_icon("lg"),
    color  = colors.icon,
    padding_left  = layout.pill_inner_pad_x,
    padding_right = 6,
  },

  label = { drawing = false },
  click_script = [[osascript -e 'tell application "Spotify" to previous track']],
})

local spotify_play = sbar.add("item", "spotify.play", {
  position = "e",
  padding_left  = 0,
  padding_right = 0,
  background = { drawing = false },

  icon = {
    string = GLYPH_PLAY,
    font   = font_icon("lg"),
    color  = colors.icon,
    padding_left  = 6,
    padding_right = 6,
  },

  label = { drawing = false },
  click_script = [[osascript -e 'tell application "Spotify" to playpause']],
})

local spotify_next = sbar.add("item", "spotify.next", {
  position = "e",
  padding_left  = 0,
  padding_right = 0,
  background = { drawing = false },

  icon = {
    string = GLYPH_NEXT,
    font   = font_icon("lg"),
    color  = colors.icon,
    padding_left  = 6,
    padding_right = 10,
  },

  label = { drawing = false },
  click_script = [[osascript -e 'tell application "Spotify" to next track']],
})

local spotify_title = sbar.add("item", "spotify.title", {
  position = "e",
  padding_left  = 0,
  padding_right = layout.pill_inner_pad_x,
  background = { drawing = false },

  icon = { drawing = false },

  label = {
    string = "",
    font   = font_text("sm"),
    color  = colors.text,
    padding_left  = 0,
    padding_right = 0,
  },

  click_script = [[osascript -e 'tell application "Spotify" to playpause']],
})

--------------------------------------------------
-- One pill wrapper around all four items
--------------------------------------------------

local spotify_bracket = sbar.add("bracket", "spotify.bracket", {
  spotify_prev.name,
  spotify_play.name,
  spotify_next.name,
  spotify_title.name,
}, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
})

--------------------------------------------------
-- Show/hide as a group (prevents “glitch”)
--------------------------------------------------

local function set_spotify_drawing(on)
  spotify_prev:set({ drawing = on })
  spotify_play:set({ drawing = on })
  spotify_next:set({ drawing = on })
  spotify_title:set({ drawing = on })
  spotify_bracket:set({ drawing = on })
end

--------------------------------------------------
-- Updater (poll Spotify; updates play icon + title)
--------------------------------------------------

local updater = sbar.add("item", "spotify.updater", {
  drawing     = false,
  updates     = true,
  update_freq = 2,
})

local function update_spotify()
  -- Single AppleScript call, safe outputs:
  -- not_running|||, stopped|||, playing|||Track, paused|||Track
  local cmd = [[osascript <<'EOF'
try
  if application "Spotify" is not running then
    return "not_running|||"
  end if
  tell application "Spotify"
    set ps to player state as string
    if ps is "stopped" then return "stopped|||"
    set t to ""
    try
      set t to name of current track as string
    end try
    return ps & "|||" & t
  end tell
on error
  return "stopped|||"
end try
EOF]]

  sbar.exec(cmd, function(out)
    out = (out or ""):gsub("[\r\n]+$", "")
    local state, track = out:match("^(.-)|||(.*)$")
    state = state or "stopped"
    track = track or ""

    if state == "not_running" or state == "stopped" then
      set_spotify_drawing(false)
      return
    end

    set_spotify_drawing(true)

    spotify_title:set({ label = { string = cut15(track) } })

    if state == "playing" then
      spotify_play:set({ icon = { string = GLYPH_PAUSE } })
    else
      spotify_play:set({ icon = { string = GLYPH_PLAY } })
    end
  end)
end

updater:subscribe({ "routine", "forced", "system_woke" }, update_spotify)
update_spotify()