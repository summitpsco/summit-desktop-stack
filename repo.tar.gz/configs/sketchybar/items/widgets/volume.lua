-- items/widgets/volume.lua
-- Volume pill + ONE big popup (slider + audio outputs), fully styled from theme.lua

local theme  = require("theme")
local colors = theme.colors
local layout = theme.layout
local font   = theme.font
local icons  = require("icons")

local popup_width = 250

--------------------------------------------------
-- MAIN PILL CONTENT (icon + percentage)
--------------------------------------------------

local volume_percent = sbar.add("item", "widgets.volume1", {
  position = "right",
  icon = { drawing = false },

  padding_left  = layout.pill_inner_pad_x,
  padding_right = layout.pill_inner_pad_x,

  background = {
    color         = colors.transparent,
    border_color  = colors.transparent,
    border_width  = 0,
    corner_radius = layout.pill_radius,
  },

  label = {
    string = "??%",
    align  = "center",
    font = {
      family = font.numbers.family,
      style  = font.style_map[font.weight_numbers],
      size   = font.sizes.sm,
    },
    color = colors.text,
  },
})

local volume_icon = sbar.add("item", "widgets.volume2", {
  position      = "right",
  padding_right = 0,

  background = {
    color         = colors.transparent,
    border_color  = colors.transparent,
    border_width  = 0,
    corner_radius = layout.pill_radius,
  },

  icon = {
    string = icons.volume._100,
    width  = 0,
    align  = "left",
    font = {
      family = font.icon.family,
      style  = font.style_map[font.weight_icons],
      size   = font.sizes.lg,
    },
    color = colors.icon,
  },

  label = {
    width = 25,
    align = "left",
    font = {
      family = font.icon.family,
      style  = font.style_map[font.weight_icons],
      size   = font.sizes.lg,
    },
    color = colors.icon,
  },
})

--------------------------------------------------
-- OUTER PILL BRACKET (shape + border)
--------------------------------------------------

local volume_bracket = sbar.add("bracket", "widgets.volume.bracket", {
  volume_icon.name,
  volume_percent.name,
}, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
  popup = {
    align = "center",
  },
})

-- Gap after the volume group
sbar.add("item", "widgets.volume.padding", {
  position = "right",
  width    = layout.group_gap,
})

--------------------------------------------------
-- POPUP: SLIDER (top row)
--------------------------------------------------

local volume_slider = sbar.add("slider", popup_width, {
  position = "popup." .. volume_bracket.name,
  align    = "center",

  slider = {
    highlight_color = colors.accent,
    background = {
      height        = 6,
      corner_radius = layout.pill_radius / 2,
      color         = colors.pill_bg_alt,
    },
    knob = {
      string  = "􀀁",
      drawing = true,
    },
  },

  -- transparent; the big popup bracket provides the pill
  background = {
    color    = colors.transparent,
    height   = 2,
    y_offset = -20,
  },

  click_script = 'osascript -e "set volume output volume $PERCENTAGE"',
})

--------------------------------------------------
-- ONE BIG POPUP BORDER (wraps slider + all device rows)
-- We include:
--   - the slider item
--   - all dynamically created items named volume.device.X via regex
--------------------------------------------------

sbar.add("bracket", "widgets.volume.popup_bracket", {
  volume_slider.name,
  "/volume.device\\..*/",
}, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    -- IMPORTANT: no fixed height here; we want it to wrap ALL popup rows
  },
})

--------------------------------------------------
-- VOLUME CHANGE HANDLER
--------------------------------------------------

volume_percent:subscribe("volume_change", function(env)
  local volume = tonumber(env.INFO) or 0
  local icon_glyph = icons.volume._0

  if volume > 60 then
    icon_glyph = icons.volume._100
  elseif volume > 30 then
    icon_glyph = icons.volume._66
  elseif volume > 10 then
    icon_glyph = icons.volume._33
  elseif volume > 0 then
    icon_glyph = icons.volume._10
  end

  local lead = (volume < 10) and "0" or ""

  volume_icon:set({ label = icon_glyph })
  volume_percent:set({ label = lead .. volume .. "%" })
  volume_slider:set({ slider = { percentage = volume } })
end)

--------------------------------------------------
-- POPUP: AUDIO DEVICE LIST
--------------------------------------------------

local function popup_is_on()
  local q = volume_bracket:query()
  if not q or not q.popup or not q.popup.drawing then return false end
  return q.popup.drawing == "on"
end

local function set_popup(on)
  volume_bracket:set({ popup = { drawing = on and true or false } })
end

local function trim_line(s)
  if not s then return "" end
  return (s:gsub("[\r\n]+$", ""))
end

local function clear_devices()
  sbar.remove("/volume.device\\..*/")
end

local current_audio_device = "None"

local function build_devices()
  clear_devices()

  sbar.exec("SwitchAudioSource -t output -c", function(result)
    current_audio_device = trim_line(result)

    sbar.exec("SwitchAudioSource -a -t output", function(available)
      local current = current_audio_device
      local counter = 0

      for device in string.gmatch(available or "", "[^\r\n]+") do
        local label_color = colors.text_muted
        if current == device then label_color = colors.text end

        sbar.add("item", "volume.device." .. counter, {
          position = "popup." .. volume_bracket.name,
          width    = popup_width,
          align    = "center",

          -- Transparent: the ONE big popup bracket provides the pill
          background = {
            color         = colors.transparent,
            border_color  = colors.transparent,
            border_width  = 0,
            corner_radius = layout.pill_radius,
          },

          label = {
            string = device,
            color  = label_color,
            font = {
              family = font.text.family,
              style  = font.style_map[font.weight_text],
              size   = font.sizes.sm,
            },
          },

          click_script =
            'SwitchAudioSource -s "' .. device .. '" ' ..
            '&& sketchybar --set /volume.device\\.*/ label.color=' .. colors.text_muted ..
            ' --set $NAME label.color=' .. colors.text,
        })

        counter = counter + 1
      end
    end)
  end)
end

local function volume_collapse_details()
  if not popup_is_on() then return end
  set_popup(false)
  clear_devices()
end

local function volume_toggle_details(env)
  if env.BUTTON == "right" then
    sbar.exec("open /System/Library/PreferencePanes/Sound.prefpane")
    return
  end

  if popup_is_on() then
    volume_collapse_details()
  else
    set_popup(true)
    build_devices()
  end
end

local function volume_scroll(env)
  local delta = env.INFO.delta
  if env.INFO.modifier ~= "ctrl" then
    delta = delta * 10.0
  end

  sbar.exec(
    'osascript -e "set volume output volume ' ..
    '(output volume of (get volume settings) + ' .. delta .. ')"'
  )
end

--------------------------------------------------
-- SUBSCRIPTIONS
--------------------------------------------------

volume_icon:subscribe("mouse.clicked",          volume_toggle_details)
volume_icon:subscribe("mouse.scrolled",         volume_scroll)
volume_percent:subscribe("mouse.clicked",       volume_toggle_details)
volume_percent:subscribe("mouse.exited.global", volume_collapse_details)
volume_percent:subscribe("mouse.scrolled",      volume_scroll)