-- items/widgets/wifi.lua
-- Felix-style stacked Wi-Fi speeds + popup
-- Theme-driven pill sizing/colors + xs fonts
-- Shows 3-digit KBPS in caps ("007 KBPS") with correct math (bytes/sec -> KBPS)

local theme = require("theme")
local icons = require("icons")

local colors = theme.colors
local layout = theme.layout
local font   = theme.font

-- Event provider: "network_update" every 2s for interface en0
sbar.exec("killall network_load >/dev/null; $CONFIG_DIR/helpers/event_providers/network_load/bin/network_load en0 network_update 2.0")

local popup_width = 250

local function numbers_font(size_key)
  return {
    family = font.numbers.family,
    style  = font.style_map[font.weight_numbers],
    size   = font.sizes[size_key],
  }
end

local function icon_font(size_key)
  return {
    family = font.icon.family,
    style  = font.style_map[font.weight_icons],
    size   = font.sizes[size_key],
  }
end

-- Convert provider string to bytes/sec.
-- Provider usually outputs like "000 Bps", but can be "KBps"/"MBps" on some setups.
local function to_bytes_per_sec(str)
  if not str or str == "" then return 0 end
  local n, unit = str:match("(%d+)%s*(%a+)")
  n = tonumber(n) or 0
  unit = unit or "Bps"

  if unit == "Bps" or unit == "BPS" then
    return n
  elseif unit == "KBps" or unit == "Kbps" or unit == "KBPS" then
    return n * 1024
  elseif unit == "MBps" or unit == "Mbps" or unit == "MBPS" then
    return n * 1024 * 1024
  end

  -- Unknown unit: assume bytes/sec
  return n
end

-- Format bytes/sec -> "XYZ KBPS" (3 digits, caps), clamped to 999.
-- Uses 1024 bytes = 1 KB (KiB) but labeled "KBPS" as requested.
local function format_3_kbps(str)
  local bytes = to_bytes_per_sec(str)
  local kb = math.floor((bytes / 1024) + 0.5) -- rounded
  if kb > 999 then kb = 999 end
  if kb < 0 then kb = 0 end
  return string.format("%03d KBPS", kb)
end

--------------------------------------------------
-- Stacked speed items (Felix-style stacking)
--------------------------------------------------

local wifi_up = sbar.add("item", "widgets.wifi.up", {
  position     = "right",
  padding_left = -5,
  width        = 0,
  y_offset     = 4,

  icon = {
    padding_right = 0,
    font          = icon_font("xs"),
    string        = icons.wifi.upload,
  },

  label = {
    font   = numbers_font("xs"),
    color  = colors.text_muted,
    string = "000 KBPS",
  },
})

local wifi_down = sbar.add("item", "widgets.wifi.down", {
  position     = "right",
  padding_left = -5,
  y_offset     = -4,

  icon = {
    padding_right = 0,
    font          = icon_font("xs"),
    string        = icons.wifi.download,
  },

  label = {
    font   = numbers_font("xs"),
    color  = colors.text_muted,
    string = "000 KBPS",
  },
})

--------------------------------------------------
-- Wi-Fi status icon (inside the same pill)
--------------------------------------------------

local wifi = sbar.add("item", "widgets.wifi.status", {
  position = "right",
  label    = { drawing = false },

  padding_left  = layout.pill_inner_pad_x,
  padding_right = 0,

  icon = {
    font   = icon_font("sm"),
    string = icons.wifi.connected,
    color  = colors.text,
  },
})

--------------------------------------------------
-- Outer pill bracket (theme-driven)
--------------------------------------------------

local wifi_bracket = sbar.add("bracket", "widgets.wifi.bracket", {
  wifi.name,
  wifi_up.name,
  wifi_down.name,
}, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
  popup = { align = "center", height = layout.pill_height },
})

--------------------------------------------------
-- Popup details (Felix behavior, theme fonts/colors)
--------------------------------------------------

local ssid = sbar.add("item", "wifi.popup.ssid", {
  position = "popup." .. wifi_bracket.name,
  icon = {
    font   = icon_font("sm"),
    string = icons.wifi.router,
    color  = colors.text,
  },
  width = popup_width,
  align = "center",
  label = {
    font      = numbers_font("sm"),
    max_chars = 18,
    string    = "—",
    color     = colors.text,
  },
  background = {
    height   = 2,
    color    = colors.pill_border,
    y_offset = -15,
  }
})

local hostname = sbar.add("item", "wifi.popup.hostname", {
  position = "popup." .. wifi_bracket.name,
  icon = {
    align  = "left",
    string = "Hostname:",
    width  = popup_width / 2,
    color  = colors.text,
    font   = numbers_font("sm"),
  },
  label = {
    max_chars = 20,
    string    = "—",
    width     = popup_width / 2,
    align     = "right",
    color     = colors.text,
    font      = numbers_font("sm"),
  }
})

local ip = sbar.add("item", "wifi.popup.ip", {
  position = "popup." .. wifi_bracket.name,
  icon = {
    align  = "left",
    string = "IP:",
    width  = popup_width / 2,
    color  = colors.text,
    font   = numbers_font("sm"),
  },
  label = {
    string = "—",
    width  = popup_width / 2,
    align  = "right",
    color  = colors.text,
    font   = numbers_font("sm"),
  }
})

local mask = sbar.add("item", "wifi.popup.mask", {
  position = "popup." .. wifi_bracket.name,
  icon = {
    align  = "left",
    string = "Subnet mask:",
    width  = popup_width / 2,
    color  = colors.text,
    font   = numbers_font("sm"),
  },
  label = {
    string = "—",
    width  = popup_width / 2,
    align  = "right",
    color  = colors.text,
    font   = numbers_font("sm"),
  }
})

local router = sbar.add("item", "wifi.popup.router", {
  position = "popup." .. wifi_bracket.name,
  icon = {
    align  = "left",
    string = "Router:",
    width  = popup_width / 2,
    color  = colors.text,
    font   = numbers_font("sm"),
  },
  label = {
    string = "—",
    width  = popup_width / 2,
    align  = "right",
    color  = colors.text,
    font   = numbers_font("sm"),
  },
})

--------------------------------------------------
-- Updates: 3-digit KBPS in caps + theme colors
--------------------------------------------------

wifi_up:subscribe("network_update", function(env)
  local up_str   = format_3_kbps(env.upload)
  local down_str = format_3_kbps(env.download)

  local up_idle   = (up_str == "000 KBPS")
  local down_idle = (down_str == "000 KBPS")

  local up_color   = up_idle and colors.text_muted or colors.text
  local down_color = down_idle and colors.text_muted or colors.text

  wifi_up:set({
    icon  = { color = up_color },
    label = { string = up_str, color = up_color },
  })

  wifi_down:set({
    icon  = { color = down_color },
    label = { string = down_str, color = down_color },
  })
end)

wifi:subscribe({ "wifi_change", "system_woke" }, function()
  sbar.exec("ipconfig getifaddr en0", function(ipaddr)
    ipaddr = (ipaddr or ""):gsub("[\r\n]", "")
    local connected = (ipaddr ~= "")
    wifi:set({
      icon = {
        string = connected and icons.wifi.connected or icons.wifi.disconnected,
        color  = connected and colors.text or colors.red,
      },
    })
  end)
end)

--------------------------------------------------
-- Popup toggle (Felix behavior)
--------------------------------------------------

local function hide_details()
  wifi_bracket:set({ popup = { drawing = false } })
end

local function toggle_details()
  local should_draw = wifi_bracket:query().popup.drawing == "off"
  if should_draw then
    wifi_bracket:set({ popup = { drawing = true } })

    sbar.exec("networksetup -getcomputername", function(result)
      hostname:set({ label = { string = (result or ""):gsub("[\r\n]", "") } })
    end)

    sbar.exec("ipconfig getifaddr en0", function(result)
      ip:set({ label = { string = (result or ""):gsub("[\r\n]", "") } })
    end)

    sbar.exec("ipconfig getsummary en0 | awk -F ' SSID : '  '/ SSID : / {print $2}'", function(result)
      ssid:set({ label = { string = (result or ""):gsub("[\r\n]", "") } })
    end)

    sbar.exec("networksetup -getinfo Wi-Fi | awk -F 'Subnet mask: ' '/^Subnet mask: / {print $2}'", function(result)
      mask:set({ label = { string = (result or ""):gsub("[\r\n]", "") } })
    end)

    sbar.exec("networksetup -getinfo Wi-Fi | awk -F 'Router: ' '/^Router: / {print $2}'", function(result)
      router:set({ label = { string = (result or ""):gsub("[\r\n]", "") } })
    end)
  else
    hide_details()
  end
end

wifi_up:subscribe("mouse.clicked", toggle_details)
wifi_down:subscribe("mouse.clicked", toggle_details)
wifi:subscribe("mouse.clicked", toggle_details)
wifi:subscribe("mouse.exited.global", hide_details)

--------------------------------------------------
-- Spacer after Wi-Fi group (theme gap)
--------------------------------------------------

sbar.add("item", "widgets.wifi.padding", {
  position = "right",
  width    = layout.group_gap,
})