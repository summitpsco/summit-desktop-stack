-- items/widgets/battery.lua
-- Battery pill & popup, styled only from theme.lua (robust + bug-fixed)

local theme  = require("theme")
local colors = theme.colors
local layout = theme.layout
local font   = theme.font
local icons  = require("icons")

--------------------------------------------------
-- MAIN BATTERY PILL (inner content only)
--------------------------------------------------

local battery = sbar.add("item", "widgets.battery", {
  position    = "right",
  update_freq = 180,

  padding_left  = layout.pill_inner_pad_x,
  padding_right = layout.pill_inner_pad_x,

  -- Ensure popup is centered consistently (no styling change)
  popup = { align = "center" },

  -- Inner item: no own fill/border, bracket handles pill look
  background = {
    color         = colors.transparent,
    border_color  = colors.transparent,
    border_width  = 0,
    corner_radius = layout.pill_radius,
  },

  icon = {
    font = {
      family = font.icon.family,
      style  = font.style_map[font.weight_icons],
      size   = font.sizes.md,
    },
    color = colors.icon,
  },

  label = {
    font = {
      family = font.numbers.family,
      style  = font.style_map[font.weight_numbers],
      size   = font.sizes.sm,
    },
    color = colors.text,
    align = "center",
  },
})

--------------------------------------------------
-- POPUP: time remaining (borderless text item)
--------------------------------------------------

local remaining_time = sbar.add("item", "widgets.battery.remaining", {
  position = "popup." .. battery.name,

  background = {
    color        = colors.transparent,
    border_color = colors.transparent,
    border_width = 0,
  },

  icon = {
    string = "TIME REMAINING:",
    align  = "left",
    font = {
      family = font.text.family,
      style  = font.style_map[font.weight_text],
      size   = font.sizes.sm,
    },
    color = colors.text,
  },

  label = {
    string = "--:--h",
    align  = "right",
    font = {
      family = font.numbers.family,
      style  = font.style_map[font.weight_numbers],
      size   = font.sizes.sm,
    },
    color = colors.text,
  },
})

--------------------------------------------------
-- POPUP PILL: single border, 100% from theme.lua
--------------------------------------------------

sbar.add("bracket", "widgets.battery.popup_bracket", { remaining_time.name }, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
})

--------------------------------------------------
-- pmset parsing + icon/colour logic
--------------------------------------------------

local function update_battery()
  sbar.exec("pmset -g batt", function(batt_info)
    local _, _, charge_str = batt_info:find("(%d+)%%")
    local charge = tonumber(charge_str) or 0

    local charging = batt_info:find("AC Power") ~= nil

    local icon_glyph
    local icon_color = colors.icon

    if charging then
      icon_glyph = icons.battery.charging
      icon_color = colors.green
    else
      if      charge > 80 then icon_glyph = icons.battery._100
      elseif  charge > 60 then icon_glyph = icons.battery._75
      elseif  charge > 40 then icon_glyph = icons.battery._50
      elseif  charge > 20 then
        icon_glyph = icons.battery._25
        icon_color = colors.orange
      else
        icon_glyph = icons.battery._0
        icon_color = colors.red
      end
    end

    battery:set({
      icon = { string = icon_glyph, color = icon_color },
      label = { string = string.format("%d%%", charge), color = colors.text },
    })
  end)
end

local function update_remaining_time()
  sbar.exec("pmset -g batt", function(batt_info)
    local _, _, remaining = batt_info:find(" (%d+:%d+) remaining")
    local label_text = remaining or "No estimate"

    remaining_time:set({
      label = { string = label_text },
    })
  end)
end

--------------------------------------------------
-- Subscriptions
--------------------------------------------------

battery:subscribe({ "forced", "routine", "power_source_change", "system_woke" }, function()
  update_battery()
end)

battery:subscribe("mouse.clicked", function()
  local q = battery:query()
  local drawing = (q and q.popup and q.popup.drawing) or "off"
  local new_state = (drawing == "on") and "off" or "on"

  battery:set({ popup = { drawing = new_state } })

  if new_state == "on" then
    update_remaining_time()
  end
end)

--------------------------------------------------
-- OUTER PILL BRACKET (main pill)
--------------------------------------------------

sbar.add("bracket", "widgets.battery.bracket", { battery.name }, {
  background = {
    color         = colors.pill_bg_main,
    height        = layout.pill_height,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
  },
})

--------------------------------------------------
-- Spacer after group
--------------------------------------------------

sbar.add("item", "widgets.battery.padding", {
  position = "right",
  width    = layout.group_gap,
})

--------------------------------------------------
-- Immediate first update (prevents stale state after reload)
--------------------------------------------------
update_battery()