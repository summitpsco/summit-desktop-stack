-- ~/.config/sketchybar/items/init.lua
-- Loads all items/widgets for the bar

-- Left side / core modules
require("items.apple")
require("items.spaces")
require("items.menus")
require("items.front_app")

-- Right side
require("items.calendar")
require("items.media")

-- Widgets (right side)
require("items.widgets.battery")
require("items.widgets.volume")
require("items.widgets.wifi")
require("items.widgets.cpu")