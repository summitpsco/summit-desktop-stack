-- items/widgets/cpu.lua
-- CPU pill (single item: icon LEFT + percentage RIGHT), fully theme-driven

local theme = require("theme")
local icons = require("icons")

local colors = theme.colors
local layout = theme.layout
local font   = theme.font

-- Event provider (fires cpu_update every 2s)
sbar.exec("killall cpu_load >/dev/null; $CONFIG_DIR/helpers/event_providers/cpu_load/bin/cpu_load cpu_update 2.0")

--------------------------------------------------
-- CPU ITEM (ICON + LABEL IN ONE ITEM)
--------------------------------------------------

local cpu = sbar.add("item", "widgets.cpu", {
  position = "right",

  padding_left  = layout.pill_inner_pad_x,
  padding_right = layout.pill_inner_pad_x,

  background = {
    color        = colors.transparent,
    border_color = colors.transparent,
    border_width = 0,
  },

  icon = {
    string        = icons.cpu,
    padding_right = 6,
    font = {
      family = font.icon.family,
      style  = font.style_map[font.weight_icons],
      size   = font.sizes.lg,
    },
    color = colors.icon,
  },

  label = {
    string = "0%",
    align  = "right",
    font = {
      family = font.numbers.family,
      style  = font.style_map[font.weight_numbers],
      size   = font.sizes.sm,
    },
    color = colors.text,
  },
})

--------------------------------------------------
-- OUTER PILL (BORDER + FILL FROM THEME)
--------------------------------------------------

sbar.add("bracket", "widgets.cpu.bracket", { cpu.name }, {
  background = {
    color         = colors.pill_bg_main,
    border_color  = colors.pill_border,
    border_width  = layout.pill_border_width,
    corner_radius = layout.pill_radius,
    height        = layout.pill_height,
  },
})

--------------------------------------------------
-- UPDATE HANDLER
--------------------------------------------------

cpu:subscribe("cpu_update", function(env)
  local load = tonumber(env.total_load) or 0
  cpu:set({ label = { string = string.format("%d%%", load) } })
end)

--------------------------------------------------
-- CLICK
--------------------------------------------------

cpu:subscribe("mouse.clicked", function()
  sbar.exec("open -a 'Activity Monitor'")
end)

--------------------------------------------------
-- SPACER
--------------------------------------------------

sbar.add("item", "widgets.cpu.padding", {
  position = "right",
  width    = layout.group_gap,
})