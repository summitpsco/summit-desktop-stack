-- items/apple.lua
-- Clickable Apple icon (menus helper), theme-driven, NO pill background.

local theme = require("theme")
local icons = require("icons")

local colors = theme.colors
local layout = theme.layout
local font   = theme.font

-- Spacer before Apple (keeps consistent gap with your other left groups)
sbar.add("item", "apple.left_padding", {
  position = "left",
  width    = layout.group_gap,
})

-- Apple logo
local apple = sbar.add("item", "apple.logo", {
  position = "left",

  icon = {
    string        = icons.apple,
    padding_left  = layout.pill_inner_pad_x,
    padding_right = layout.pill_inner_pad_x,
    color         = colors.icon,
    font = {
      family = font.icon.family,
      style  = font.style_map[font.weight_icons],
      size   = font.sizes.xxl,
    },
  },

  label = { drawing = false },

  -- No pill / border (matches your intent)
  background = {
    color        = colors.transparent,
    border_color = colors.transparent,
    border_width = 0,
  },

  padding_left  = 0,
  padding_right = 0,

  click_script = "$CONFIG_DIR/helpers/menus/bin/menus -s 0",
})

-- Spacer after Apple
sbar.add("item", "apple.right_padding", {
  position = "left",
  width    = layout.group_gap,
})