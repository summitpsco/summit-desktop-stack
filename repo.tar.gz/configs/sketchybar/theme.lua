-- theme.lua
-- Single source of truth for ALL SketchyBar appearance.

local theme = {}

--------------------------------------------------
-- COLORS
--------------------------------------------------

theme.colors = {
  -- Bar
  bar_bg          = 0x80181819,  -- main bar background (with alpha)
  bar_border      = 0xff2c2e34,  -- bar border

  -- Pills (chips)
  pill_bg_main    =0xcc000000,  -- primary pill colour
  pill_bg_alt     = 0x80181819,  -- secondary pill colour

  pill_border     = 0x00000000,  -- main pill border colour (single border look)
  pill_border_alt = 0xff7f8490,  -- optional secondary border colour

  -- Text + icons
  text            = 0xffe2e2e3,  -- main text
  text_muted      = 0xff7f8490,  -- less important text
  icon            = 0xffe2e2e3,  -- default icon colour
  icon_active     = 0xffffffff,  -- active / highlighted icon

  -- Accent
  accent          = 0xff76cce0,  -- accent line / highlights

  -- Palette (CPU/battery states, etc.)
  black           = 0xff181819,
  white           = 0xffe2e2e3,
  grey            = 0xff7f8490,
  red             = 0xfffc5d7c,
  green           = 0xff9ed072,
  blue            = 0xff76cce0,
  yellow          = 0xffe7c664,
  orange          = 0xfff39660,
  magenta         = 0xffb39df3,

  transparent     = 0x00000000,
}

-- Alpha helper (only when you explicitly want transparency)
function theme.colors.with_alpha(color, alpha)
  local a = math.floor(alpha * 255.0) & 0xff
  return (color & 0x00ffffff) | (a << 24)
end

--------------------------------------------------
-- LAYOUT
--------------------------------------------------

theme.layout = {
  -- Bar geometry
  bar_height        = 32,
  bar_corner_radius = 10,

  -- Pill geometry
  pill_height       = 24,
  pill_radius       = 8,

  -- Single border thickness for pills
  pill_border_width = 1,

  -- Padding / gaps
  pill_inner_pad_x  = 8,   -- left/right padding inside each pill
  group_gap         = 5,   -- gap between pill groups

  -- Widget-specific layout
  wifi_y_offset     = 4,   -- vertical offset to stack wifi up/down rows
  wifi_icon_width   = 36,  -- horizontal space reserved for wifi icon
}

--------------------------------------------------
-- FONTS (single place to control everything)
--------------------------------------------------

-- Raw font config
theme.font_config = {
  text_family    = "SF Pro Display", -- front app, calendar, labels
  icon_family    = "SF Pro Display", -- icons that use a font
  numbers_family = "SF Pro Display", -- battery %, CPU %, time, wifi BPS

  style_map = {
    Regular = "Regular",
    Medium  = "Medium",
    Bold    = "Bold",
    Black   = "Black",
  },

  -- Global weights (flip these to change everything)
  weight_text    = "Black",   -- big text (front app, calendar)
  weight_icons   = "Regular", -- icon glyphs
  weight_numbers = "Black",   -- numeric values (percentages, time, BPS)

  sizes = {
    xxs = 8.0,   -- ultra small (wifi up/down)
    xs  = 8.0,
    sm  = 11.0,
    md  = 12.0,
    lg  = 13.0,
    xl  = 14.0,
    xxl = 16.0,
  },
}

-- Flattened view that all widgets will use
theme.font = {
  text = {
    family = theme.font_config.text_family,
  },
  icon = {
    family = theme.font_config.icon_family,
  },
  numbers = {
    family = theme.font_config.numbers_family,
  },

  style_map      = theme.font_config.style_map,
  sizes          = theme.font_config.sizes,
  weight_text    = theme.font_config.weight_text,
  weight_icons   = theme.font_config.weight_icons,
  weight_numbers = theme.font_config.weight_numbers,
}

--------------------------------------------------
-- SHIM TO MATCH OLD SETTINGS SHAPE
-- (so existing files keep working while we convert)
--------------------------------------------------

-- These match the old `settings.paddings` / `settings.group_paddings`
theme.paddings       = theme.layout.pill_inner_pad_x
theme.group_paddings = theme.layout.group_gap

-- Icon set name
theme.icons = "sf-symbols"

return theme